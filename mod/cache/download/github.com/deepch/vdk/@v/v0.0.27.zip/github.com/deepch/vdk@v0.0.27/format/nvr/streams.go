package nvr

import "github.com/deepch/vdk/av"

type Stream struct {
	codec av.CodecData
	idx   int
}
